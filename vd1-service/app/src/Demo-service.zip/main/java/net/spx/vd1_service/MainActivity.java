package net.spx.vd1_service;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // tạo intent để khởi động service
        Intent intent = new Intent(MainActivity.this, DemoService001.class);
        startService(intent);




    }
}